"""
PDF Master Pro - PDF Viewer Widget
High-performance native Qt document canvas with zoom, smooth scrolling, and page controls.
"""
from typing import Optional
from pathlib import Path

from PySide6.QtWidgets import (
    QWidget, QVBoxLayout, QHBoxLayout, QLabel, QPushButton, QComboBox,
    QScrollArea, QLineEdit, QTabBar, QSpacerItem, QSizePolicy, QFileDialog
)
from PySide6.QtCore import Qt, Signal, QSize
from PySide6.QtGui import QPixmap, QImage, QWheelEvent, QResizeEvent
from PySide6.QtPdf import QPdfDocument, QPdfDocumentRenderOptions

class PDFCanvas(QScrollArea):
    page_changed = Signal(int)
    zoom_changed = Signal(int)

    def __init__(self, parent=None):
        super().__init__(parent)
        self.doc: Optional[QPdfDocument] = None
        self.current_page = 0
        self.zoom_factor = 1.0 # 100%
        self.init_ui()

    def init_ui(self):
        self.setAlignment(Qt.AlignCenter)
        self.setStyleSheet("background-color: #101924; border: none;")

        self.page_label = QLabel()
        self.page_label.setAlignment(Qt.AlignCenter)
        self.page_label.setStyleSheet("background-color: white; border-radius: 4px; box-shadow: 0 4px 6px rgba(0,0,0,0.3);")
        self.setWidget(self.page_label)
        self.setWidgetResizable(True)

    def set_document(self, doc: QPdfDocument):
        self.doc = doc
        self.current_page = 0
        self.render_current_page()

    def set_page(self, page_index: int):
        if not self.doc or self.doc.pageCount() == 0:
            return
        if 0 <= page_index < self.doc.pageCount():
            self.current_page = page_index
            self.render_current_page()
            self.page_changed.emit(self.current_page)

    def set_zoom(self, zoom_pct: int):
        self.zoom_factor = max(0.2, min(4.0, zoom_pct / 100.0))
        self.render_current_page()
        self.zoom_changed.emit(int(self.zoom_factor * 100))

    def render_current_page(self):
        if not self.doc or self.doc.pageCount() == 0:
            self.page_label.clear()
            return

        pt_size = self.doc.pagePointSize(self.current_page)
        render_opts = QPdfDocumentRenderOptions()
        
        # Base scale 1.5 for crisp screen rendering
        pixel_w = int(pt_size.width() * 1.5 * self.zoom_factor)
        pixel_h = int(pt_size.height() * 1.5 * self.zoom_factor)

        q_img = self.doc.render(self.current_page, QSize(pixel_w, pixel_h), render_opts)
        pixmap = QPixmap.fromImage(q_img)
        self.page_label.setPixmap(pixmap)
        self.page_label.setFixedSize(pixel_w, pixel_h)

    def wheelEvent(self, event: QWheelEvent):
        if event.modifiers() & Qt.ControlModifier:
            delta = event.angleDelta().y()
            if delta > 0:
                self.set_zoom(int(self.zoom_factor * 100) + 10)
            else:
                self.set_zoom(int(self.zoom_factor * 100) - 10)
            event.accept()
        else:
            super().wheelEvent(event)

class PDFViewer(QWidget):
    page_changed = Signal(int)
    zoom_changed = Signal(int)
    toggle_thumbnails_clicked = Signal()
    new_tab_clicked = Signal()

    def __init__(self, parent=None):
        super().__init__(parent)
        self.doc = QPdfDocument(self)
        self.current_file_path: Optional[str] = None
        self.init_ui()

    def init_ui(self):
        layout = QVBoxLayout(self)
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)

        # Tab Bar
        tab_layout = QHBoxLayout()
        tab_layout.setContentsMargins(8, 4, 8, 0)
        self.tab_bar = QTabBar()
        self.tab_bar.setTabsClosable(True)
        self.tab_bar.tabCloseRequested.connect(self.on_tab_close)
        tab_layout.addWidget(self.tab_bar)

        self.btn_add_tab = QPushButton("➕")
        self.btn_add_tab.setFixedSize(30, 28)
        self.btn_add_tab.setToolTip("فتح مستند جديد في تبويب")
        self.btn_add_tab.clicked.connect(self.new_tab_clicked.emit)
        tab_layout.addWidget(self.btn_add_tab)
        tab_layout.addStretch()
        layout.addLayout(tab_layout)

        # Navigation Toolbar
        toolbar_widget = QWidget()
        toolbar_widget.setStyleSheet("background-color: #172536; border-bottom: 1px solid #24374D;")
        toolbar = QHBoxLayout(toolbar_widget)
        toolbar.setContentsMargins(12, 6, 12, 6)
        toolbar.setSpacing(8)

        self.btn_toggle_thumbs = QPushButton("📑")
        self.btn_toggle_thumbs.setFixedSize(32, 30)
        self.btn_toggle_thumbs.setToolTip("إظهار / إخفاء المصغرات")
        self.btn_toggle_thumbs.clicked.connect(self.toggle_thumbnails_clicked.emit)
        toolbar.addWidget(self.btn_toggle_thumbs)

        self.btn_prev = QPushButton("◀")
        self.btn_prev.setFixedSize(32, 30)
        self.btn_prev.clicked.connect(self.prev_page)
        toolbar.addWidget(self.btn_prev)

        self.page_input = QLineEdit("1")
        self.page_input.setFixedWidth(45)
        self.page_input.setAlignment(Qt.AlignCenter)
        self.page_input.returnPressed.connect(self.on_page_input)
        toolbar.addWidget(self.page_input)

        self.page_total_lbl = QLabel("/ 0")
        self.page_total_lbl.setStyleSheet("color: #94A3B8; font-weight: bold;")
        toolbar.addWidget(self.page_total_lbl)

        self.btn_next = QPushButton("▶")
        self.btn_next.setFixedSize(32, 30)
        self.btn_next.clicked.connect(self.next_page)
        toolbar.addWidget(self.btn_next)

        toolbar.addSpacing(16)

        # Zoom Controls
        self.btn_zoom_out = QPushButton("🔍-")
        self.btn_zoom_out.setFixedSize(36, 30)
        self.btn_zoom_out.clicked.connect(self.zoom_out)
        toolbar.addWidget(self.btn_zoom_out)

        self.zoom_combo = QComboBox()
        self.zoom_combo.setFixedWidth(85)
        self.zoom_combo.addItems(["50%", "75%", "100%", "125%", "150%", "200%"])
        self.zoom_combo.setCurrentText("100%")
        self.zoom_combo.currentTextChanged.connect(self.on_zoom_combo_changed)
        toolbar.addWidget(self.zoom_combo)

        self.btn_zoom_in = QPushButton("🔍+")
        self.btn_zoom_in.setFixedSize(36, 30)
        self.btn_zoom_in.clicked.connect(self.zoom_in)
        toolbar.addWidget(self.btn_zoom_in)

        toolbar.addStretch()
        layout.addWidget(toolbar_widget)

        # Canvas
        self.canvas = PDFCanvas()
        self.canvas.page_changed.connect(self.on_canvas_page_changed)
        self.canvas.zoom_changed.connect(self.on_canvas_zoom_changed)
        layout.addWidget(self.canvas)

    def load_pdf(self, file_path: str, password: Optional[str] = None) -> bool:
        self.current_file_path = file_path
        if password:
            self.doc.setPassword(password)
        err = self.doc.load(file_path)
        if err != QPdfDocument.Error.None_:
            return False

        self.tab_bar.clear()
        self.tab_bar.addTab(f"📄 {Path(file_path).name}")
        self.page_total_lbl.setText(f"/ {self.doc.pageCount()}")
        self.page_input.setText("1")

        self.canvas.set_document(self.doc)
        return True

    def on_tab_close(self, index: int):
        self.doc.close()
        self.tab_bar.clear()
        self.canvas.page_label.clear()
        self.page_total_lbl.setText("/ 0")
        self.page_input.setText("1")
        self.current_file_path = None

    def prev_page(self):
        if self.canvas.current_page > 0:
            self.canvas.set_page(self.canvas.current_page - 1)

    def next_page(self):
        if self.doc and self.canvas.current_page < self.doc.pageCount() - 1:
            self.canvas.set_page(self.canvas.current_page + 1)

    def on_page_input(self):
        txt = self.page_input.text().strip()
        if txt.isdigit() and self.doc:
            num = int(txt) - 1
            if 0 <= num < self.doc.pageCount():
                self.canvas.set_page(num)

    def on_canvas_page_changed(self, p_idx: int):
        self.page_input.setText(str(p_idx + 1))
        self.page_changed.emit(p_idx)

    def on_canvas_zoom_changed(self, pct: int):
        self.zoom_combo.blockSignals(True)
        self.zoom_combo.setCurrentText(f"{pct}%")
        self.zoom_combo.blockSignals(False)
        self.zoom_changed.emit(pct)

    def zoom_in(self):
        cur = int(self.canvas.zoom_factor * 100)
        self.canvas.set_zoom(cur + 15)

    def zoom_out(self):
        cur = int(self.canvas.zoom_factor * 100)
        self.canvas.set_zoom(cur - 15)

    def on_zoom_combo_changed(self, text: str):
        val = text.replace("%", "").strip()
        if val.isdigit():
            self.canvas.set_zoom(int(val))
